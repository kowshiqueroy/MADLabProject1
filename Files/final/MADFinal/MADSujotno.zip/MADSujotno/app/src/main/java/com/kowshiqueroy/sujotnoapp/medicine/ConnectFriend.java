package com.kowshiqueroy.sujotnoapp.medicine;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.kowshiqueroy.sujotnoapp.R;
import com.kowshiqueroy.sujotnoapp.alarm.ReminderFragment;
import com.kowshiqueroy.sujotnoapp.report.MonthlyReportPresenter;

public class ConnectFriend extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connect_friend);
    }

    public void Cloudsave(View view) {
    }

    public void CloudsaveFind(View view) {

        TextView t= findViewById(R.id.v);
        t.setText(ReminderFragment.data);
    }
}