package com.kowshiqueroy.sujotnoapp.addmedicine;

import com.kowshiqueroy.sujotnoapp.BasePresenter;
import com.kowshiqueroy.sujotnoapp.BaseView;
import com.kowshiqueroy.sujotnoapp.data.source.MedicineAlarm;
import com.kowshiqueroy.sujotnoapp.data.source.Pills;

import java.util.List;



public interface AddMedicineContract {

    interface View extends BaseView<Presenter> {

        void showEmptyMedicineError();

        void showMedicineList();

        boolean isActive();

    }

    interface  Presenter extends BasePresenter{


        void saveMedicine(MedicineAlarm alarm, Pills pills);


        boolean isDataMissing();

        boolean isMedicineExits(String pillName);

        long addPills(Pills pills);

        Pills getPillsByName(String pillName);

        List<MedicineAlarm> getMedicineByPillName(String pillName);

        List<Long> tempIds();

        void deleteMedicineAlarm(long alarmId);

    }
}
