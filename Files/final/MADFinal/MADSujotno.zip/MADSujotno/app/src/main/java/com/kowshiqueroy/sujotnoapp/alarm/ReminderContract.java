package com.kowshiqueroy.sujotnoapp.alarm;

import com.kowshiqueroy.sujotnoapp.BasePresenter;
import com.kowshiqueroy.sujotnoapp.BaseView;
import com.kowshiqueroy.sujotnoapp.data.source.History;
import com.kowshiqueroy.sujotnoapp.data.source.MedicineAlarm;



public interface ReminderContract {

    interface View extends BaseView<Presenter> {

        void showMedicine(MedicineAlarm medicineAlarm);

        void showNoData();

        boolean isActive();

        void onFinish();

    }

    interface Presenter extends BasePresenter {

        void finishActivity();

        void onStart(long id);

        void loadMedicineById(long id);

        void addPillsToHistory(History history);

    }
}
