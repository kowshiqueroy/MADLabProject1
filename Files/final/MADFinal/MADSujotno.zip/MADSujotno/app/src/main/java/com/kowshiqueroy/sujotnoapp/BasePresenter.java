package com.kowshiqueroy.sujotnoapp;


public interface BasePresenter {

    void start();
}
