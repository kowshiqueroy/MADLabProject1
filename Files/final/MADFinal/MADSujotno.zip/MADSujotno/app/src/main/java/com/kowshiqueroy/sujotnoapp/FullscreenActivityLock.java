package com.kowshiqueroy.sujotnoapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import androidx.appcompat.app.AppCompatActivity;

import com.kowshiqueroy.sujotnoapp.medicine.MedicineActivity;

public class FullscreenActivityLock extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    // Objects.requireNonNull(getSupportActionBar()).hide();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

     /*   View over= findViewById(R.id.mylayout);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            over.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION );
        }*/

        setContentView(R.layout.activity_fullscreen_lock);
    }

    public void unclock(View view) {
        Intent ii = new Intent(FullscreenActivityLock.this, MedicineActivity.class);
        startActivity(ii);
    }
}