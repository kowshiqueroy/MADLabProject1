package com.kowshiqueroy.sujotnoapp.report;

/**
 * Created by Kowshique on 22.8.22.
 */

public enum  FilterType {

    ALL_MEDICINES,

    TAKEN_MEDICINES,

    IGNORED_MEDICINES
}
